create function update_last_update_time_4_base_accounts() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW."last_update_time" := now();
    RETURN NEW;
END
$$;

alter function update_last_update_time_4_base_accounts() owner to djing2_usr;

