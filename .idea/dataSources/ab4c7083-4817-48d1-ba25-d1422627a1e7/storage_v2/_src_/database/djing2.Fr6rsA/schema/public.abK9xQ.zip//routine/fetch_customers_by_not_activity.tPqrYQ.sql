create function fetch_customers_by_not_activity(date_limit timestamp with time zone, out_limit integer) returns SETOF customers_afk_type
    language sql
as
$$
WITH afk AS (
    SELECT MAX(CL.date)     AS last_date,
           CL.customer_id,
           MAX(BA.username) AS customer_uname,
           MAX(BA.fio)      AS customer_fio
    FROM customer_log CL
             LEFT JOIN base_accounts BA ON CL.customer_id = BA.id
             LEFT JOIN customers CS ON BA.id = CS.baseaccount_ptr_id
    WHERE CL.cost < 0
      AND BA.is_active
      AND CS.current_service_id IS NULL
    GROUP BY CL.customer_id
)
SELECT (NOW() - afk.last_date) as timediff, afk.*
FROM afk
WHERE afk.last_date < date_limit
LIMIT out_limit;
$$;

alter function fetch_customers_by_not_activity(timestamp with time zone, integer) owner to djing2_usr;

