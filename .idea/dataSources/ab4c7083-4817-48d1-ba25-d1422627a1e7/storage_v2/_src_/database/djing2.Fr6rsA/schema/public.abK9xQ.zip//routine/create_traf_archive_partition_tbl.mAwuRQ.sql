create function create_traf_archive_partition_tbl(whentime timestamp without time zone) returns boolean
    language plpgsql
as
$$
DECLARE
  v_next_week_start timestamp;
  v_next_week_end timestamp;
  v_parition_name text;
BEGIN

  v_next_week_start := date_trunc('week', whentime);
  v_parition_name := format('traf_archive_%s', to_char(v_next_week_start, 'YYYYMMIW'));
  if exists(
    select from information_schema.tables
    where table_schema = 'public'
    and table_name = v_parition_name
  ) then
      return false;
  end if;

  v_next_week_end := v_next_week_start + '1 week'::interval - '1 sec'::interval;

  execute 'create unlogged table if not exists ' || v_parition_name || '(like traf_archive including all)';
  execute 'alter table ' || v_parition_name || ' inherit traf_archive';
  execute format('alter table %I add constraint partition_check check (event_time >= ''%s'' and event_time < ''%s'')',
    v_parition_name,
    v_next_week_start,
    v_next_week_end);

  return true;
END
$$;

alter function create_traf_archive_partition_tbl(timestamp) owner to djing2_usr;

