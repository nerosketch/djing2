create function update_customer_lease_last_update_time_field(v_customer_id integer, v_client_ip inet) returns void
    language sql
as
$$
    -- Update `last_update` field in leases
update networks_ip_leases nil
set last_update = now()
where nil.customer_id = v_customer_id
  and nil.ip_address = v_client_ip
  and nil.is_dynamic
$$;

alter function update_customer_lease_last_update_time_field(integer, inet) owner to djing2_usr;

