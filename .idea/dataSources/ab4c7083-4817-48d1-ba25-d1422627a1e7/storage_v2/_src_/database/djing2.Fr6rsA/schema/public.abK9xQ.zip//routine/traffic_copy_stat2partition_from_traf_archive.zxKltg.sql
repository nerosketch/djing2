create function traffic_copy_stat2partition_from_traf_archive() returns trigger
    language plpgsql
as
$$
DECLARE
  v_parition_name text;
BEGIN
  v_parition_name := format('traf_archive_%s', to_char(NEW.event_time, 'YYYYMMIW'));
  execute 'INSERT INTO ' || v_parition_name || ' VALUES ( ($1).* ) ON CONFLICT DO NOTHING' using NEW;
  return NULL;
END
$$;

alter function traffic_copy_stat2partition_from_traf_archive() owner to djing2_usr;

