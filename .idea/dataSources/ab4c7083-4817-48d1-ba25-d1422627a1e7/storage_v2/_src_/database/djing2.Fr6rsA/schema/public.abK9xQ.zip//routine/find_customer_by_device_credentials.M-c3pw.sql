create function find_customer_by_device_credentials(v_dev_mac macaddr, v_dev_port smallint) returns SETOF customers
    language sql
as
$$
-- find customer by device mac and device port
select cs.*
from customers cs
  left join device dv on (dv.id = cs.device_id)
  left join device_port dp on (cs.dev_port_id = dp.id)
  left join device_dev_type_is_use_dev_port ddtiudptiu on (ddtiudptiu.dev_type = dv.dev_type)
where dv.mac_addr = v_dev_mac
      and ((not ddtiudptiu.is_use_dev_port) or dp.num = v_dev_port)
limit 1;
$$;

alter function find_customer_by_device_credentials(macaddr, smallint) owner to djing2_usr;

