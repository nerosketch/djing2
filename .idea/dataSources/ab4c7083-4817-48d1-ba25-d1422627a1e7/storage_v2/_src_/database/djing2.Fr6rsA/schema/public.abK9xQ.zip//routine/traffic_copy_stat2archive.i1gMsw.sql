create function traffic_copy_stat2archive() returns trigger
    language plpgsql
as
$$
DECLARE
  v_parition_name text;
BEGIN
  v_parition_name := format('traf_archive_%s', to_char(NEW.event_time, 'YYYYMMIW'));
  execute format('INSERT INTO %I(customer_id,event_time,octets,packets) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING;', v_parition_name)
    using NEW.customer_id, NEW.event_time, NEW.octets, NEW.packets;
  return NULL;
END
$$;

alter function traffic_copy_stat2archive() owner to djing2_usr;

