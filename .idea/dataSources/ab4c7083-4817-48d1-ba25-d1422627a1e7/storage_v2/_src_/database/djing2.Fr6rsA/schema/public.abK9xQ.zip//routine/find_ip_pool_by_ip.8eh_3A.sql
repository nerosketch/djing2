create function find_ip_pool_by_ip(v_ip inet) returns SETOF networks_ip_pool
    language sql
as
$$
select *
from networks_ip_pool
where
  v_ip <<= network
limit 1
for update skip locked;
$$;

alter function find_ip_pool_by_ip(inet) owner to djing2_usr;

