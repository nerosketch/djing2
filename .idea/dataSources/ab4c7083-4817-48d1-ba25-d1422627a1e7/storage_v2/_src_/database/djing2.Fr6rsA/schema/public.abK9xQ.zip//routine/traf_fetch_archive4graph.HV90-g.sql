create function traf_fetch_archive4graph(v_customer bigint, v_start_date timestamp without time zone, v_end_date timestamp without time zone) returns SETOF traffetcharchivereturntype
    language sql
as
$$
select date_trunc('hour', event_time) +
          date_part('minute', event_time) :: int / 5 * interval '5 min' as trnk,
          sum(octets)                                                   as octsum,
          sum(packets)                                                  as pctsum
   from traf_archive
   where event_time > v_start_date
     and event_time < v_end_date
     and customer_id = v_customer
   group by 1
   order by 1
$$;

alter function traf_fetch_archive4graph(bigint, timestamp, timestamp) owner to djing2_usr;

